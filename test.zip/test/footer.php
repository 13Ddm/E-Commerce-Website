<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/mainsite.css">
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
</head>
<body>
	<footer><div class="bottom1">
<div class="col1">
	<img src="img/D4.jpg">
	<h3>Best Prices & Offers</h3>
	<p>Enjoy the lowest prices in the City, Express & Food Hall store!</p>
</div>
<div class="col1 ">
	<img src="img/D5.jpg">
	<h3>Wide Assortment</h3>
	<p>Choose from a variety of products from branded, chilled, fresh & frozen.</p>
</div>
<div class="col1 ">
	<img src="img/D6.jpg">
	<h3>Easy Returns</h3>
	<p>Not satisfied with a product? Return it at the doorstep & get a refund within hours.</p>
</div>


<div class="useful-links">
	<h3>Useful Links</h3>
	<ul>
		<li><a href="#">Contact Us</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Terms & Conditions</a></li>
		<li><a href="#">Privacy Policy</a></li>
</ul>
</div>

<div class="social">
	<h3>Follow Us</h3>
	<ul>
		<li><a href="#"><i class="fab fa-facebook"></i></a></li>
      	<li><a href="#"><i class="fab fa-instagram-square"></i></a></li>
      	<li><a href="#"><i class="fab fa-twitter fa-fw"></i></a></li>
      	<li><a href="#"><i class="fab fa-youtube-square"></i></a></li>	


	</ul>
</div>
<div class="app"><h3>Download the App</h3>
	<img src="img/qr2.png" class="qr2">
	<img src="img/android.png" height="40px" width="120px">
	<img src="img/apple.png" height="40px" width="120px">
</div>
<div class="copyright">
	&copy;Cheap Store Online 2020-2021
</div>


     </div></footer>
</body>










</html>