<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php include ('header.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: login.php');
	}

	$user_list = '';
	$search1=''; ?>


	<!DOCTYPE html>
<html >
<head>
	<meta charset="utf-8">
	<title>Cheap Store</title>
	<link rel="stylesheet" type="text/css" href="css/mainsite.css">
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
	
</head>
<body>

<div class="methods">
     	
<!-- Display the countdown timer in an element -->
<h2>Sale Ending In : </h2><p id="demo"></p></div>

<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2022 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>


<!-- Slideshow container -->
<div class="slideshow-container">

  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    
    <img src="img/slide1.jpg" width="100%" >
    
  </div>

  <div class="mySlides fade">
    
    <img src="img/slide2.png" width="100%">
    
  </div>

  <div class="mySlides fade">
    
    <img src="img/slide3.png" width="100%">
    
  </div>
  <div class="mySlides fade">
    
    <img src="img/slide4.jpg" width="100%">
    
  </div>
  <div class="mySlides fade">
    
    <img src="img/slide5.png" width="100%">
    
  </div>



  <!-- Next and previous buttons -->
  
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
  <span class="dot" onclick="currentSlide(4)"></span>
  <span class="dot" onclick="currentSlide(5)"></span>
</div>
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 4000); // Change image every 4 seconds
}
</script>

<div class="search1">
	<form method="post" action="test2.php"> 
		<input type="text" name="search1" placeholder="Search"><button>Search</button>
		</form>
</div>

<div class="site-middle">
	<h2>Shop by Category</h2>
		<a href="category.php" class="view">View All &raquo;</a>
		<div class="col">
	<img src="img/snacks.jpg">
	<a href="snacks.php"><h3>Snacks</h3></a>
</div>
<div class="col">
	<img src="img/beverages2.jpg">
	<a href="snacks.php"><h3>Beverages</h3></a>
</div>
<div class="col">
	<img src="img/persnl safty.jpg">
	<a href="snacks.php"><h3>Personal Saftey</h3></a>
</div>
<div class="col">
	<img src="img/stationary.png" height="225px" width="225px">
	<a href="snacks.php"><h3>Stationary Items</h3></a>
</div>
<div class="col">
	<img src="img/diary3.jpg">
	<a href="snacks.php"><h3>Diary Items</h3></a>
</div>
	</div>

	<div class="message">
		<b>Dear Customer,</b><br>
	Please note that our delivery slot may be full and new slots will be released each day at 12am! Alternatively..<br>
	Our teams will do there best to serve you.<br> Thank You for understanding.
	</div>

     <div class="bottom1">
     	<div class="text1">
     		<p>Enter Sri Lanka's one of the freshest online grocery store for all your grocery needs- fresh to frozen and everything in between! Now, you can order ALL your daily necessities from the comfort of your home or anywhere you want! Choose from same-day, next-day & saver to ensure you get what you need when you need it.</p>
     	</div>
<div class="col1">
	<img src="img/D4.jpg">
	<h3>Best Prices & Offers</h3>
	<p>Enjoy the lowest prices in the City, Express & Food Hall store!</p>
</div>
<div class="col1 ">
	<img src="img/D5.jpg">
	<h3>Wide Assortment</h3>
	<p>Choose from a variety of products from branded, chilled, fresh & frozen.</p>
</div>
<div class="col1 ">
	<img src="img/D6.jpg">
	<h3>Easy Returns</h3>
	<p>Not satisfied with a product? Return it at the doorstep & get a refund within hours.</p>
</div>


<div class="useful-links">
	<h3>Useful Links</h3>
	<ul>
		<li><a href="#">Contact Us</a></li>
		<li><a href="#">FAQ</a></li>
		<li><a href="#">Terms & Conditions</a></li>
		<li><a href="#">Privacy Policy</a></li>
</ul>
</div>

<div class="social">
	<h3>Follow Us</h3>
	<ul>
		<li><a href="#"><i class="fab fa-facebook"></i></a></li>
      	<li><a href="#"><i class="fab fa-instagram-square"></i></a></li>
      	<li><a href="#"><i class="fab fa-twitter fa-fw"></i></a></li>
      	<li><a href="#"><i class="fab fa-youtube-square"></i></a></li>	


	</ul>
</div>
<div class="app"><h3>Download the App</h3>
	<img src="img/qr2.png" class="qr2">
	<img src="img/android.png" height="40px" width="120px">
	<img src="img/apple.png" height="40px" width="120px">
</div>
<div class="copyright">
	&copy;Cheap Store Online 2020-2021
</div>


     </div>












	</body></html>
	