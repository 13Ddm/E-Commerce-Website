<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: login.php');
	}

	$user_list = '';
	$search='';

	// getting the list of users
	if (isset($_GET['search'])){
		$search=mysqli_real_escape_string($connection, $_GET['search']);
		$query = "SELECT * FROM orders WHERE (order_id LIKE '%{$search}%' OR cus_id LIKE '%{$search}%' OR pid LIKE '%{$search}%' OR address LIKE '%{$search}%' OR contact LIKE '%{$search}%' OR payment LIKE '%{$search}%') ORDER BY order_id";
	}else{
		$query = "SELECT * FROM orders ORDER BY cus_id";
	}
	$users = mysqli_query($connection, $query);

	verify_query($users);

	while ($user = mysqli_fetch_assoc($users)) {
		$user_list .= "<tr>";
		$user_list .= "<td>{$user['order_id']}</td>";
		$user_list .= "<td>{$user['cus_id']}</td>";
		$user_list .= "<td>{$user['pid']}</td>";
		$user_list .= "<td>{$user['address']}</td>";
		$user_list .= "<td>{$user['contact']}</td>";
		$user_list .= "<td>{$user['payment']}</td>";
		
	
		$user_list .= "</tr>";
	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Orders</title>
	<link rel="stylesheet" href="css/adminusers.css">
</head>
<body>
	<header>
		<div class="appname">Cheap Store-User Management System</div>
		<div class="loggedin">Welcome <?php echo $_SESSION['first_name']; ?>! <a href="logout.php">Log Out</a></div>
	</header>



<nav >
      	<ul>
      		<li><a href="users.php">Users</a></li>
      		<li><a href="admincategory.php">Category</a></li>
      		<li><a href="adminproducts.php">Products</a></li>
      		<li><a href="adminorders.php">Orders</a></li> </nav>
      		
      	</ul>






	<main>
		<h1>Orders<span><a href="add-orders2.php">  Place an Order</a> | <a href="users.php">Refresh</a></span></h1>


		<div class="search">
			<form action="users.php" method="get">
				<p>
				<input type="text" name="search" id="" placeholder="Type Order ID and Press Enter" value="<?php echo $search; ?>"required autofocus></p>
			</form>
		</div>

		<table class="masterlist">
			<tr>
				<th>Order ID</th>
				<th>Customer ID</th>
				<th>Product ID</th>
				<th>Address</th>
				<th>Contact</th>
				<th>Payment</th>
				
			</tr>

			<?php echo $user_list; ?>

		</table>
		
		
	</main>
</body>
</html>