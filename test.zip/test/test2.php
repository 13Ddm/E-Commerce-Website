<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php include ('header.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: login.php');
	}

	$user_list = '';
	$search='';

	// getting the list of users
	if (isset($_GET['search'])){
		$search=mysqli_real_escape_string($connection, $_GET['search']);
		$query = "SELECT * FROM product WHERE (pro_name LIKE '%{$search}%') ORDER BY pro_name";
	}else{
		$query = "SELECT * FROM category  ORDER BY cat_id";
	}
	$users = mysqli_query($connection, $query);

	verify_query($users);


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 
           



</head>

	<header>
		
	</header>










	<main>
		

		<div class="search">
			<form action="test2.php" method="get">
				<p>
				<input type="text" name="search" id="" placeholder="Type & Press Enter" style="width:500px; padding: 6px; font-size: 15px; border: 1px solid black; margin-left: 450px; margin-top:10px " value="<?php echo $search; ?>"required autofocus> </p>
			</form>
		</div>

		<body>
			<div class="container" style="width:700px;">  
                <h3 align="center"></h3><br />  
                <?php  
                $query = "SELECT * FROM product WHERE (pro_name LIKE '%{$search}%') ORDER BY pro_name";  
                $result = mysqli_query($connection, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?> 
                <div class="col-md-4">  
                     <form method="post" action="test2.php?<?php echo $row["pid"]; ?>">  
                          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px; margin-top: 10px" align="center">  
                               <img src="<?php echo $row["photo"]; ?>" class="img-responsive" /><br />  
                               <h4 class="text-info"><?php echo $row["pro_name"]; ?></h4>  
                               <h4 class="text-danger">Rs. <?php echo $row["price"]; ?></h4>  
                               <input type="text" pro_name="quantity" class="form-control" value="1" />  
                               <input type="hidden" pro_name="hidden_pro_name" value="<?php echo $row["pro_name"]; ?>" />  
                               <input type="hidden" pro_name="hidden_price" value="<?php echo $row["price"]; ?>" />  
                               <input type="submit" pro_name="add_to_cart" style="margin-top:5px; color: white; background:#8c8c8c; border: black;" class="btn btn-success" value="Add to Cart"/>  
                          </div>  
                     </form>  
                </div>  
                <?php  
                     }  
                }  
                ?>  
                <div style="clear:both"></div>  
                <br />  
                <h3>Order Details</h3>  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                               <th width="40%">Item Name</th>  
                               <th width="10%">Quantity</th>  
                               <th width="20%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="5%">Action</th>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><?php echo $values["item_name"]; ?></td>  
                               <td><?php echo $values["item_quantity"]; ?></td>  
                               <td>$ <?php echo $values["item_price"]; ?></td>  
                               <td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>  
                               <td><a href="search2.php?action=delete&pid=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>  
                          </tr>  
                          <?php  
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">$ <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
           <br /> 
           
      </body>  <footer><?php include ('footer.php') ?> </footer>
 </html>