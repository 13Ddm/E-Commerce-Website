<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: index.php');
	}

	$errors = array();
	$cus_id = '';
	$pid = '';
	$address = '';
	$contact = '';
	$payment = '';
	

	if (isset($_POST['submit'])) {
		
		$cus_id = $_POST['cus_id'];
		$pid = $_POST['pid'];
		$address = $_POST['address'];
		$contact = $_POST['contact'];
		$address = $_POST['address'];


		
		// checking required fields
		$req_fields = array('cus_id', 'pid', 'address' , 'contact', 'payment');
		$errors = array_merge($errors, check_req_fields($req_fields));

		// checking max length
		$max_len_fields = array( 'address' => 100,'payment' =>100);
		$errors = array_merge($errors, check_max_len($max_len_fields));

		
foreach($req_fields as $field){
				if (empty(trim($_POST[$field]))){
					$errors[]= $field . ' is required';
				}
			}



		

		$result_set = mysqli_query($connection, $query);

		

		if (empty($errors)) {
			// no errors found... adding new record
			$cus_id = mysqli_real_escape_string($connection, $_POST['cus_id']);
			$pid    = mysqli_real_escape_string($connection, $_POST['pid']);
			$address= mysqli_real_escape_string($connection, $_POST['address']);
			$contact= mysqli_real_escape_string($connection, $_POST['contact']);
			$payment= mysqli_real_escape_string($connection, $_POST['payment']);

			$query = "INSERT INTO orders ( ";
			$query .= "cus_id, pid, address, contact, payment";
			$query .= ") VALUES (";
			$query .= "'{$cus_id}', '{$pid}', '{$address}', '{$contact}','{$payment}'";
			$query .= ")";

			$result = mysqli_query($connection, $query);

			if ($result) {
				// query successful... redirecting to users page
				header('Location: adminorders.php?order_added=true');
			} else {
				$errors[] = 'Failed to add the new record.';
			}


		}



	}



?>








<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Place an Order</title>
	<link rel="stylesheet" href="css/adminusers.css">
</head>
<body>
	<header>
		<div class="appname">Cheap User Management System</div>
		<div class="loggedin">Welcome <?php echo $_SESSION['first_name']; ?>! <a href="logout.php">Log Out</a></div>
	</header>

	<main>
		<h1>Place an Order<span> <a href="adminorders.php"> < Back </a></span></h1>

		<?php 

			if (!empty($errors)) {
				display_errors($errors);
			}

		 ?>

		<form action="adminorders.php" method="post" class="userform">
			
			<p>
				<label for="">Customer ID:</label>
				<input type="text" name="cus_id" <?php echo 'value="' . $cus_id . '"'; ?> required>
			</p>

			<p>
				<label for="">Product ID:</label>
				<input type="text" name="pid" <?php echo 'value="' . $pid . '"'; ?> required>
			</p>

			<p>
				<label for="">Address:</label>
				<input type="text" name="address" <?php echo 'value="' . $address . '"'; ?> required>
			</p>
			<p>
				<label for="">Contact:</label>
				<input type="text" name="contact" <?php echo 'value="' . $contact . '"'; ?> required>
			</p>
			<p>
				<label for="">Payment:</label>
				<input type="text" name="payment" <?php echo 'value="' . $payment . '"'; ?> required>
			</p>








			<p>
				<label for="">&nbsp;</label>
				<button type="submit" name="submit">Save</button>
			</p>

		</form>

		
		
	</main>
</body>
</html>