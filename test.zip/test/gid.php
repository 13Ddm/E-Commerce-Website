<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php include ('header.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: login.php');
	}

	$user_list = '';
	$search=''; ?>





<!DOCTYPE html>
<html >
<head>
	<meta charset="utf-8">
	<title>Cheap Store</title>
	<link rel="stylesheet" type="text/css" href="css/gid.css">
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
	
</head>
<body>
	
	<div class="aboutus">
		<h1>Get It Delivered</h1><br>

<img src="img/gid3.jpg" width="1200px" height="450px"><br>

		<h2>About Us</h2><br>
		<p>
With experience and the aptitude of serving the nation for over a decade, GID is the ultimate domestic courier service provider in Sri Lanka. The stability and the accuracy gained through our vast years of service and experience, GID functions with the highest confidence in widest coverage, security and the rapid delivery of your packages.With the strength of an experienced and talented team, GID also possesses a strong background in logistics management. As a result of the trust we have been maintaining with our corporate clients, today GID serves as the official courier for numerous entities in Sri Lanka.Domex maintains high service standards with the optimum levels of quality to ensure that your packages are handled by professionals. With a large network which keeps expanding to cover each and every corner of Sri Lanka, GID serves as the fastest courier in domestic delivery service in Sri Lanka.</p>
	</div>

	<div class="vision">
		<h2>Our Vision</h2><br>
		<p>To be the best domestic courier service company in Sri Lanka and to continue branching out to win the hearts of our customers by becoming a household name in every town, city and village by maintaining the highest standards of service and advancing technologically with the ever changing times.</p>
	</div>
	<div class="mission">
		<h2>Our Mission</h2><br>
		<p>A well-established domestic courier service company that serves and delivers to all parts of the nation whilst maintaining the highest standards of efficiency and serving to fulfill all our customers needs to the best of our abilities.</p>
	</div><br>
	<div class="footer">
		<div class="social-media">
			<h2>Follow us on </h2>
			<ul>
				<li><a href="#"><i class="fab fa-facebook"></i></a></li>
				<li><a href="#"><i class="fab fa-instagram-square"></i></a></li>
      			<li><a href="#"><i class="fab fa-twitter fa-fw"></i></a></li>
      			<li><a href="#"><i class="fab fa-youtube-square"></i></a></li>	
      			
            </ul>
		
		</div>
		<div class="payments">
			
		</div>
		</div>