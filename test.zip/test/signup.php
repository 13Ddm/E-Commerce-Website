<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>

<?php 
		$errors=array();

		if (isset($_POST['submit'])){

			//checking required fields
			$req_fields =array('first_name','last_name','email','password');

			foreach($req_fields as $field){
				if (empty(trim($_POST[$field]))){
					$errors[]= $field . ' is required';
				}
			}

			//checking required fields
		/*	if (empty(trim($_POST['first_name']))){
				$errors[]='First Name is Required.';
			}
			if (empty(trim($_POST['last_name']))){
				$errors[]='Last Name is Required.';
			}
			if (empty(trim($_POST['email']))){
				$errors[]='Email is Required.';
			}
			if (empty(trim($_POST['password']))){
				$errors[]='Password is Required.';
			} */

			//checking maximum length
			$max_len_fields =array('first_name'=>50,'last_name'=>50,'email'=>100,'password'=>40);

			foreach($max_len_fields as $field=>$max_len){
				if (strlen(trim($_POST[$field])) > $max_len){
					$errors[]= $field . ' must be less than ' . $max_len . ' characters.';
				}
			}
		//checking if email address already exists
			$email=mysqli_real_escape_string($connection, $_POST['email']);
			$query="SELECT * FROM users WHERE email ='{$email}' LIMIT 1";

			$result_set=mysqli_query($connection, $query);

			if ($result_set){
				if (mysqli_num_rows($result_set) ==1){
					$errors[] = 'Email Address already exists.';
				}
			}
				if (empty($errors)){

					//if no errors found add the new record.
            $first_name=mysqli_real_escape_string($connection, $_POST['first_name']);
            $last_name=mysqli_real_escape_string($connection, $_POST['last_name']);
            $password=mysqli_real_escape_string($connection, $_POST['password']);

            //email address is already sanitized.
            $hashed_password=sha1($password);

            $query= "INSERT INTO users (";
            $query .= "first_name, last_name, email, password";
            $query .=") VALUES (";
            $query .="'{$first_name}','{$last_name}','{$email}', '{$hashed_password}'";
            $query .=")";

            $result_set=mysqli_query($connection,$query);

            if ($result_set){
            	//if the query successful.....redirecting to main page
            	header('Location: main.php?user_added=true');
				}else{
					$errors[]='Failed to add the new record';
				}
            }

		}

 ?>

			
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="css/signup.css">
	<meta charset="utf-8">
	<title>Sign Up </title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

</head>
<body>
	<header>
	<div class="appname"></div><h2>Sign Up & Get Offers</h2>
	<img src="img/discount.gif"  >
</header>
<main>

            
	<?php 
			if (!empty($errors)){
				echo '<div class="errmsg">';
				echo '<b> There were error(s) in your form.</b><br>';
				foreach($errors as $error){
					echo $error . '<br>';
				}
				echo '</div>';
			}


	 ?>

	<form action="signup.php" method="post" class="userform">
		<p>
			<label for="">First Name:</label>
			<input type="text" name="first_name" autofocus="">
		</p>
		<p>
			<label for="">Last Name:</label>
			<input type="text" name="last_name">
		</p>
		<p>
			<label for="">Email Address:</label>
			<input type="email" name="email">
		</p>
		<p>
			<label for="">New Password:</label>
			<input type="password" name="password" id="showpw" >
			<div class="show">
			<input type="checkbox" onclick="myFunction()"><label>Show Password</label>
			</div>
		</p>
		<p>
			<label for="">&nbsp;</label>
			<button type="submit" name="submit">Save</button>
		</p>
	</form>
	
</main> 

<script>function myFunction() {
  var x = document.getElementById("showpw");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

</script>


</body>
</html>