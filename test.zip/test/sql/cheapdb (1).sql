-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2021 at 06:43 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cheapdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(1, 'Baby Products'),
(2, 'Beverages'),
(3, 'Food Cupboard'),
(4, 'Dairy Products'),
(5, 'Personal Care'),
(6, 'Stationary'),
(7, 'Snacks'),
(8, 'Cooking Essentials '),
(9, 'Pharmacy'),
(10, 'Personal Safety ');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `cus_id` int(10) NOT NULL,
  `pid` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` int(12) NOT NULL,
  `payment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `cus_id`, `pid`, `address`, `contact`, `payment`) VALUES
(1, 15, 12, '12,Colombo Road Kurunegala', 745236441, 'Cash on Delivery'),
(6, 12, 33, 'No:12/132, Kurunegala', 0, 'Cash on Delivery'),
(14, 1, 33, 'No:122, Kandy Road, Kurunegala', 0, 'Cash on Delivery'),
(16, 10, 85, 'No:120/10, Kandy Road, Kurunegala', 0, 'Paypal');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `pro_name` varchar(200) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `photo` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pro_name`, `cat_id`, `price`, `photo`) VALUES
(2, 'Baby Milk Powder', 1, 750, 'img/nangrow.png'),
(3, 'Baby Cologne', 1, 275, 'img/babycolong.png'),
(4, 'Baby Cream', 1, 300, 'img/babycream.png'),
(5, 'Baby Cereal ', 1, 450, 'img/babycereal.png'),
(6, 'Baby Soap', 1, 150, 'img/soap.png'),
(7, 'Corn Flakes', 3, 500, 'img/foodcupbrd1.jpg'),
(8, 'Coca Cola', 2, 150, 'img/cocacola.jpg'),
(9, 'Sprite ', 2, 150, 'img/sprite.jpg'),
(10, 'Orange Crush', 2, 200, 'img/orangecrush.jpg'),
(11, 'Soda', 2, 150, 'img/soda150.jpg'),
(12, 'Ratti Milk', 4, 350, 'img/milk.jpg'),
(13, 'Milk Toffee ', 4, 310, 'img/milkt.jpg'),
(14, ' Ice Cream', 4, 40, 'img/ice.jpg'),
(15, 'Curd', 4, 180, 'img/curd.jpg'),
(16, 'Nesomalt', 4, 350, 'img/nestomalt.jpg'),
(17, 'Dettol Soap', 5, 75, 'img/dettolsoap.jpg'),
(18, 'Lifebuoy Soap', 5, 65, 'img/life.jpg'),
(19, 'Rani Soap', 5, 50, 'img/ranisoap.jpg'),
(20, 'Signal Toothpaste', 5, 100, 'img/sgnl.jpg'),
(21, 'Toothpaste', 5, 95.5, 'img/t2.jpg'),
(22, 'Pen', 6, 20, 'img/pen.jpg'),
(23, 'Pencil', 6, 15, 'img/pencils.jpg'),
(24, 'Book', 6, 100, 'img/book2.jpg'),
(25, 'Book CR', 6, 230, 'img/book230.jpg'),
(26, 'Color Pencils ', 6, 1000, 'img/colourpencils1000.jpg'),
(27, 'Platignum Set', 6, 800, 'img/platignum.jpg'),
(28, 'Chocolate ', 7, 400, 'img/sugrfr.jpg'),
(29, 'Milk Chocolate', 7, 300, 'img/revellomilk.jpg'),
(30, 'Oreo Biscuit ', 7, 400, 'img/ore.jpg'),
(31, 'Chocolate Biscuit', 7, 250, 'img/chocobis.jpg'),
(32, 'Milk Chocolate', 7, 375.5, 'img/choco.png'),
(33, 'Wheat Flour ', 8, 250, 'img/wheatflour.jpg'),
(34, 'Salt', 8, 75, 'img/salt.jpg'),
(36, 'Rice Naadu', 8, 550, 'img/naadu.jpg'),
(37, 'Rice-Rathukakulu', 8, 650, 'img/kakulurathu.jpg'),
(38, 'Rice Keerisamba', 8, 850, 'img/keeri5.jpg'),
(39, 'Coconut Milk Powder', 8, 500, 'img/coco.jpg'),
(40, 'Coconut Oil', 8, 1450, 'img/oil1400.jpg'),
(41, 'Asamodagam', 9, 110, 'img/asamodagam.jpg'),
(42, 'Eno', 9, 200, 'img/eno.jpg'),
(43, 'Panadol', 9, 350, 'img/panadol.jpg'),
(44, 'AXE oil', 9, 500, 'img/axe.jpg'),
(45, 'Hand Sanitizer', 10, 800, 'img/britolsani800.jpeg'),
(46, 'Hand Sanitizer-5L', 10, 3000, 'img/Hicare-5L3000.jpg'),
(47, 'Hand Sanitizer-Dettol', 10, 250, 'img/detolsani.jpg'),
(48, 'Mask-Respirone', 10, 200, 'img/mask.jpg'),
(49, 'Soya Meat', 3, 75, 'img/soya2.jpg'),
(50, 'Maggi Noodles', 3, 85, 'img/maggi.jpg'),
(51, 'Soya Meat', 3, 80, 'img/soyameat.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `cus_id` int(10) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `last_login` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`cus_id`, `first_name`, `last_name`, `email`, `password`, `last_login`) VALUES
(1, 'Kalum', 'Bandara', 'kalumbandara@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '2021-09-17 19:49:43'),
(3, 'Gihan', 'Perera', 'gihan@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '0000-00-00 00:00:00'),
(4, 'Nalini', 'Perera', 'nalini@gmail.com', '4cdf074b71282ce3fdb3672b4969ce3352ff3c28', '0000-00-00 00:00:00'),
(5, 'Nalini', 'Perera', 'nalini@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '0000-00-00 00:00:00'),
(6, 'Kamal', 'Perera', 'kamal@yahoo.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '0000-00-00 00:00:00'),
(7, 'Amara', 'Bandara', 'amara123@gmail.com', '1d9e5eb12f9fdbe59d2c7a67eedbfb816f86ca2f', '0000-00-00 00:00:00'),
(8, 'Nayana', 'Kumari', 'nayana@gmail.com', '35a1307e5488bc91f49e87dd1afd8841993d890f', '0000-00-00 00:00:00'),
(9, 'Nayani', 'Perera', 'nayani@yahoo.com', 'f460517c6a7c1c0051f399ab8bb6533cab0f2e71', '0000-00-00 00:00:00'),
(10, 'Namal', 'Perera', 'namal@gmail.com', '28024a160358e4eeb7c4880ce062054b7ddc1c68', '0000-00-00 00:00:00'),
(11, 'Nimal', 'Wickramasingha', 'nimal@gmail.com', '5ac270fd6bb0e427005b95744797ba44ab866be7', '0000-00-00 00:00:00'),
(12, 'Kalum', 'Bandara', 'kalumbandara@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '0000-00-00 00:00:00'),
(13, 'Lakshani', 'Perera', 'lakshani@gmail.com', 'f9bb5f8dad6428d1fe8f1ebeb0bd22afee6e6fa9', '0000-00-00 00:00:00'),
(14, 'Sanduni', 'Bandara', 'sanduni@gmail.com', '678b959d0961260b32d33b5dbd93bb3528e9fd40', '0000-00-00 00:00:00'),
(15, 'dasun', 'kalana', 'dasun@gmail.com', '2a1ce84c239d31a61920321d3d00f76e7dbd7a75', '0000-00-00 00:00:00'),
(16, 'Sadun', 'Perera', 'sandun@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '0000-00-00 00:00:00'),
(17, 'Pawani', 'Perera', 'pawani@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '2021-09-17 19:07:32'),
(18, 'Wathsala', 'Perera', 'www@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '0000-00-00 00:00:00'),
(19, 'Gayan', 'Perera', 'gayan@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `cus_id` (`cus_id`),
  ADD KEY `cus_id_2` (`cus_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `foreign` (`cat_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`cus_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `cus_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`cus_id`) REFERENCES `users` (`cus_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `foreign` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`) ON DELETE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
