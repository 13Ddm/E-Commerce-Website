<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: index.php');
	}

	$errors = array();
	$pro_name = '';
	$cat_id = '';
	$price = '';
	

	if (isset($_POST['submit'])) {
		
		$pro_name = $_POST['pro_name'];
		$cat_id = $_POST['cat_id'];
		$price = $_POST['price'];
		
		// checking required fields
		$req_fields = array('pro_name', 'cat_id', 'price');
		$errors = array_merge($errors, check_req_fields($req_fields));

		// checking max length
		$max_len_fields = array('pro_name' => 50, 'cat_id' =>100, 'price' => 100);
		$errors = array_merge($errors, check_max_len($max_len_fields));

		

		

		$result_set = mysqli_query($connection, $query);

		

		if (empty($errors)) {
			// no errors found... adding new record
			$pro_name = mysqli_real_escape_string($connection, $_POST['pro_name']);
			$cat_id = mysqli_real_escape_string($connection, $_POST['cat_id']);
			$price = mysqli_real_escape_string($connection, $_POST['price']);
			
			

			$query = "INSERT INTO product ( ";
			$query .= "pro_name, cat_id, price";
			$query .= ") VALUES (";
			$query .= "'{$pro_name}', '{$cat_id}', '{$price}'";
			$query .= ")";

			$result = mysqli_query($connection, $query);

			if ($result) {
				// query successful... redirecting to users page
				header('Location: adminusers.php?product_added=true');
			} else {
				$errors[] = 'Failed to add the new record.';
			}


		}



	}



?>








<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Add New Product</title>
	<link rel="stylesheet" href="css/adminusers.css">
</head>
<body>
	<header>
		<div class="appname">Cheap User Management System</div>
		<div class="loggedin">Welcome <?php echo $_SESSION['first_name']; ?>! <a href="logout.php">Log Out</a></div>
	</header>

	<main>
		<h1>Add New Product<span> <a href="imageupload.php"> Upload Image</a> <a href="adminproducts.php"> < Back </a></span></h1>

		<?php 

			if (!empty($errors)) {
				display_errors($errors);
			}

		 ?>

		<form action="adminproducts.php" method="post" class="userform">
			
			<p>
				<label for="">Product Name:</label>
				<input type="text" name="pro_name" <?php echo 'value="' . $pro_name . '"'; ?> required>
			</p>

			<p>
				<label for="">Category ID:</label>
				<input type="text" name="cat_id" <?php echo 'value="' . $cat_id . '"'; ?> required>
			</p>

			<p>
				<label for="">Price:</label>
				<input type="text" name="price" <?php echo 'value="' . $price . '"'; ?> required>
			</p>










			<p>
				<label for="">&nbsp;</label>
				<button type="submit" name="submit">Save</button>
			</p>

		</form>

		
		
	</main>
</body>
</html>