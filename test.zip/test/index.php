<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Cheap Store</title>
	<link rel="stylesheet" type="text/css" href="css/welcome2.css">
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
</head>
<body>
<header>
	<div class="welcome">
		<h1> Welcome to Cheap Store !</h1> 
		<a href="adminlogin.php">Admin Login</a>
	</div></header>
	<div class="welcome-middle">
		<div class="gif">
		<img src="img/stickergiant-swipe-up.gif"></div>
		<div class="payments">
			<img src="img/payop.png" >
		</div>
		<div class="log-in">
			<p>New Member? <b><br>Sign Up Now !</b></p><br>
			<a href="signup.php">Sign Up </a><i class="fas fa-sign-in-alt"></i>
		</div>
		<div class="log-in">
			<p>Already a Member?<b> Log In </b></p><br>
			<a href="login.php">Log In </a><i class="fas fa-sign-in-alt"></i>
		</div>
	</div>

	<div class="welcome-bottom">
		<div class="social-media">
			<h2>Order From Social Media</h2><br>
			<ul>
				<li><a href="#"><i class="fab fa-facebook"></i></a></li>
				<li><a href="#"><i class="fab fa-facebook-messenger"></i></a></li>
      			<li><a href="#"><i class="fab fa-whatsapp"></i></a></li>
      			<li><a href="#"><i class="fab fa-telegram"></i></a></li>
      			<li><a href="#"><i class="fab fa-viber"></i></a></li>
      			
            </ul>
      		<h2>Follow us</h2><br>
			<ul>
				<li><a href="#"><i class="fab fa-facebook"></i></a></li>
      			<li><a href="#"><i class="fab fa-instagram-square"></i></a></li>
      			<li><a href="#"><i class="fab fa-twitter fa-fw"></i></a></li>
      			<li><a href="#"><i class="fas fa-rss fa-fw"></i></a></li>
      			<li><a href="#"><i class="fab fa-youtube-square"></i></a></li>	
      			
      		</ul>

			<div class="copy">
	 &copy;Cheap Store Online 2020-2021
            </div>

            <div class="call">
			<b><h2>You Can Call Us & Place Your Order</h2><br>
				<img src="img/output-onlinepngtools.png"><br>
			<p>037-2233445 / 071-1247855</p></b><br>
			<div class="Help "><b>Help Center</b>
				<ul>
					<li>&raquo; Address: No:12,Colombo Road,Kurunegala</li>
					<li>&raquo; Email: cheapstore@gmail.com</li>
					<li>&raquo; Hotline: 037-2233445</li>
					<li>&raquo; Delivery Service Hotline: 037-4455775</li>

				</ul></div>
				<div class="pic ">
            </div>
		</div>
		
		
	</div>