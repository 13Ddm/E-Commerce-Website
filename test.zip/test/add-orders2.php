<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>

<?php 
		$errors=array();
		$cus_id='';
		$pid='';
		$address='';
		$contact='';
		$payment='';

		if (isset($_POST['submit'])){

			//checking required fields
			$req_fields =array('cus_id','pid','address','payment');

			

			//checking required fields
		/*	if (empty(trim($_POST['first_name']))){
				$errors[]='First Name is Required.';
			}
			if (empty(trim($_POST['last_name']))){
				$errors[]='Last Name is Required.';
			}
			if (empty(trim($_POST['email']))){
				$errors[]='Email is Required.';
			}
			if (empty(trim($_POST['password']))){
				$errors[]='Password is Required.';
			} */

			//checking maximum length
			$max_len_fields =array('address'=>100,'payment'=>100);

			foreach($max_len_fields as $field=>$max_len){
				if (strlen(trim($_POST[$field])) > $max_len){
					$errors[]= $field . ' must be less than ' . $max_len . ' characters.';
				}
			}
		

			
				if (empty($errors)){

					//if no errors found add the new record.
            $cus_id=mysqli_real_escape_string($connection, $_POST['cus_id']);
            $pid=mysqli_real_escape_string($connection, $_POST['pid']);
            $address=mysqli_real_escape_string($connection, $_POST['address']);
            
             $payment=mysqli_real_escape_string($connection, $_POST['payment']);

            

            $query= "INSERT INTO orders (";
            $query .= "cus_id, pid, address, payment";
            $query .=") VALUES (";
            $query .="'{$cus_id}','{$pid}','{$address}', '{$payment}'";
            $query .=")";

            $result_set=mysqli_query($connection,$query);

            if ($result_set){
            	//if the query successful.....redirecting to users page
            	header('Location: users.php?order_added=true');
				}else{
					$errors[]='Failed to add the new record';
				}
            }

		}

 ?>

			
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="css/signup.css">
	<meta charset="utf-8">
	<title>Sign Up </title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="css/adminusers.css">

</head>
<body>
	<header>
	<div class="appname">Cheap User Management System</div>
		<div class="loggedin">Welcome! <a href="logout.php">Log Out</a></div>
</header>
<main> <h1>Place an Order<span> <a href="adminorders.php"> < Back </a></span></h1>

            
	

	<form action="add-orders2.php" method="post" class="userform">
		<p>
			<label for="">Customer ID:</label>
			<input type="text" name="cus_id" autofocus="" required>
		</p>
		<p>
			<label for="">Product ID:</label>
			<input type="text" name="pid"   required>
		</p>
		<p>
			<label for="">Address:</label>
			<input type="text" name="address" required >
		</p>
		
		<p>
			<label for="">Payment Method:</label>
			<input type="text" name="payment"  required>
			
		</p>
		<p>
			<label for="">&nbsp;</label>
			<button type="submit" name="submit">Save</button>
		</p>
	</form>
	
</main> 




</body>
</html>