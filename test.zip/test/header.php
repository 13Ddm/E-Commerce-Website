
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: login.php');
	}

	$user_list = '';
	$search=''; ?>


	<!DOCTYPE html>
<html >
<head>
	<meta charset="utf-8">
	<title>Cheap Store</title>
	<link rel="stylesheet" type="text/css" href="css/site.css">
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
	
</head>
<body>
	<div class="wrapper ">
		<div class="top-bar ">
		
			<div class="logo">
				 <p><b>$ Cheap Store $</b></p>
			</div>
			
			<div class="cart">

             
              




				
			</div>
			<div class="loggedin ">Welcome <?php echo $_SESSION['first_name']; ?> ! <a href="logout.php">Log Out</a></div>
		</div>
		<nav >
      	<ul>
      		<li><a href="main.php">Home</a></li>
      		<li><a href="category.php">Category</a></li>
      		<li><a href="payments.php">Payment Methods</a></li>
      		<li><a href="gid.php">Delivery Service</a></li> 
      		
      		
      	</ul>
	</div>