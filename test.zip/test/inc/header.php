<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: login.php');
	}

	$user_list = '';
	$search=''; ?>


	<!DOCTYPE html>
<html >
<head>
	<meta charset="utf-8">
	<title>Cheap Store</title>
	<link rel="stylesheet" type="text/css" href="css/site.css">
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
	
</head>
<body>
	<div class="wrapper ">
		<div class="top-bar clearfix">
		
			<div class="logo">
				 <p><b>$ Cheap Store $</b></p>
			</div>
			<div class="search">
				<form method="get" action="main.html">
         		<input type="search" name="search-box">
         		<button type="submit"></button>
         	</form>
			</div><br>
			<div class="cart">
				<a href="#"><i class="fas fa-shopping-cart"></i></a>
			</div>
			<div class="loggedin ">Welcome <?php echo $_SESSION['first_name']; ?> ! <a href="logout.php">Log Out</a></div>
		</div>
		<nav >
      	<ul>
      		<li><a href="main.php">Home</a></li>
      		<li><a href="category.php">Category</a></li>
      		<li><a href="#">About us</a></li>
      		<li><a href="gid.php">Delivery Service</a></li> </nav>
      		
      	</ul>
	</div>