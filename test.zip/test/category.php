<?php session_start(); ?>
<?php require_once('inc/connection.php'); ?>
<?php require_once('inc/functions.php'); ?>
<?php include ('header.php'); ?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		header('Location: login.php');
	}

	$user_list = '';
	$search=''; ?>





<!DOCTYPE html>
<html >
<head>
	<meta charset="utf-8">
	<title>Cheap Store</title>
	<link rel="stylesheet" type="text/css" href="css/category.css">
	<script src="https://kit.fontawesome.com/e2a31c4a3b.js" crossorigin="anonymous"></script>
	
</head>
<body>
	<div class="content">
		<h2>Categories</h2>

<div class="col">
	<img src="img/snacks.jpg">
	<a href="snacks.php"><h3>Snacks</h3><br></a>
</div>
<div class="col">
	<img src="img/diary3.jpg">
	<a href="diary.php"><h3>Diary Items</h3><br></a>
</div>
<div class="col">
	<img src="img/beverages2.jpg">
	<a href="beverages.php"><h3>Beverages</h3><br></a>
</div>
<div class="col">
	<img src="img/personal care.jpg">
	<a href="personal.php"><h3>Personal Care</h3><br></a>
</div>
<div class="col">
	<img src="img/foodcupbrd2.jpg">
	<a href="foodcup.php"><h3>Food Cupboard</h3><br></a>
</div>


<div class="col">
	<img src="img/parmacy.jpg">
	<a href="pharmacy.php"><h3>Pharmacy</h3><br></a>
</div>
<div class="col">
	<img src="img/persnl safty.jpg">
	<a href="saftey.php"><h3>Personal Saftey</h3><br></a>
</div>
<div class="col">
	<img src="img/bby.jpg">
	<a href="baby.php"><h3>Baby Products</h3><br></a>
</div>
<div class="col">
	<img src="img/rice.png" height="225px" width="225px">
	<a href="cooking.php"><h3>Cooking Essentials</h3><br></a>
</div>
<div class="col">
	<img src="img/stationary.png" height="225px" width="225px">
	<a href="stationary.php"><h3>Stationary Items</h3><br></a>
</div>








	</div>
	
</body><footer><?php include ('footer.php') ?></footer>

</html><?php mysqli_close($connection); ?>